clear
cat /etc/passwd
clear
apt
clear
apt update
ls
ls
cd /
ls
cd etc/
ls
cd apt/
ls
nano sources.list
ls
clear
cat sources.list
apt update
clear
clear
cd cd .
ls
cd /
ls
clear
paswd
clesr
clear
passwd
quit
exit
clear
off
clear
turnoff
poweroff
poweroff
clear
cd /
ls
clear
hostnamectl set-hostname TPServer
ls
hostname
clear
apt update
apt upgrade -y
nano /etc/apt/sources.list
clear
nano /etc/apt/sources.list
clear
apt update
apt full-upgrade -y
reboot
clear
cd etc
ls
cd /etc
ls
cd /debian
ls
clear
ls
cat debian_version
clear
poweroff
clear
exit
exit
clear
exit
exit
clear
exit
exit
clear
 mariadb -e "CREATE DATABASE ingenieria;"
  mariadb -e "CREATE USER 'lcars'@'localhost' IDENTIFIED BY 'NCC1701D';"
  mariadb -e "GRANT ALL PRIVILEGES ON ingenieria.* TO 'lcars'@'localhost';"
  mariadb -e "FLUSH PRIVILEGES;"
  mariadb ingenieria < "/root/material adicional/db.sql"
  mariadb -e "SHOW TABLES;" ingenieria
  mariadb -e "DROP DATABASE ingenieria;"
  mariadb -e "DROP USER 'lcars'@'localhost';"
  mariadb < "/root/material adicional/db.sql"
clear
  mariadb -e "SHOW TABLES;" ingenieria
clear
  cp "/root/material adicional/index.php" /var/www/html/
  rm /var/www/html/index.html
ip -a
ip addr
clear
cd /eyv
cd /etc
ls
cd /hosts
clare
clear
cd network/
ls
nano interfaces
systemctl restart networking
clear
clear
apt update
apt-get install openssh-server
cd /
cd /etc/ssh
ls
clear
ls -la
ip
clear
whichip
clear
cd /
ls
who
whoami
clear
ip
ls
clear
cat /etc/hosts/interfaces
cat /etc/host/interfaces
ls
cd /etc/hosts
ls
cd /etc
ls
ls -la
cd ssh
ls
clear
ls
cd .
cd ..
ls
cd /hosts
nano hosts
clear
ls
clear
cd /ssh
ls
cd ssh
ls
clear
ls
cd sshd_config
cat sshd_config
clear
vim
nano sshd_config
clear
cd /
systemctl restart ssh
clear
ls
cd etc/ssh
ls
nano sshd_config
clear
systemctl restart ssh
clear
wh ip
 ip a
192.168.1.86
clear
cd /
ls
nano sshd_config
clear
cd /
cd /etc/ssh
nano sshd_config
clear
clear
cd /
systemctl restart ssh
clear
ls
cd /etc
ls
cd ssh
ls
cd ..
cd .ssh
ls
cd ./ssg
cd ./ssh
ls
clar
clear
ls -la
ls
cd ..
ls
cat ./ssh/authorized_keys
cd ..
clear
ls
la -la
ls -la
cd home
s
ls -la
clear
cd /
ls
cd /etc
ñs
ls
clear
ls -la
clear
cd ssh
ls
nano sshd_config
nano sshd_config
clear
systemctl restart ssh
clear
cd /
find / -name "authorized_keys"
cat /root/.ssh/authorized_keys
nano /root/.ssh/authorized_keys
clear
systemctl restart ssh
clear
apt-get install apache2 php libapache2-mod-php php-mysql mariadb-server -y
clear
s
ls
cd root
ls
ls -la
clear
mkdir -p /mnt/mac
mount -t 9p -o trans=virtio share /mnt/mac
ls /mnt/mac
ls
ls
clear
mkdir -p "/root/material adicional"
cp /mnt/mac index.php "/root/material adicional"
cp /mnt/mac/index.php "/root/material adicional"
cp /mnt/mac/db.sql "/root/material adicional"
clearc
clear
systemctl status apache2
systemctl status mariadb
clear
ip -a
poweroff
clear
clear
lsblk
 fdisk /dev/vdb
clear
  mkfs.ext4 /dev/vdb1
  mkfs.ext4 /dev/vdb2
  mkdir /www_dir
  mkdir /backup_dir
  mount /dev/vdb1 /www_dir
  mount /dev/vdb2 /backup_dir
 nano /etc/fstab
 cp /var/www/html/index.php /www_dir/
  nano /etc/apache2/sites-available/000-default.conf
clear
systemctl restart apache2
 chmod 755 /www_dir
  chmod 644 /www_dir/index.php
  nano /etc/apache2/sites-available/000-default.conf
  nano /etc/apache2/sites-available/000-default.conf
clear
  systemctl restart apache2
}  cat /proc/partitions > /opt/particion
cat /proc/partitions > /opt/particion
reboot
ls
clear
ls
cd /
ls
ip -a
ip a
systemctl status ssh
clear
ls
cd stc
cd etc
ls
cd sh
ssg
cd ssh
ls
clear
cd ..
ls
cd ,,
ls
clear
cd ..
cd .shh
cd etc
cd .ssh
ls
cd /
ls
clear
cat ~/.ssh
cat ~/.ssh/authorized_keys
poweroff
