#!/bin/bash

if [ "$1" == "-help" ]; then
    echo "Uso: $0 <origen> <destino>"
    exit 0
fi

if [ ! -d "$1" ]; then
    echo "El origen no existe"
    exit 1
fi

if [ ! -d "$2" ]; then
    echo "El destino no existe"
    exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename $1)

  tar -czf $2/${NOMBRE}_bkp_${FECHA}.tar.gz $1
